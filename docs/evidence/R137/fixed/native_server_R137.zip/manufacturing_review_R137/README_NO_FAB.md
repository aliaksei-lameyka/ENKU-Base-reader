# ENKU R137 manufacturing review — NO FAB

Engineering review only. Fabrication, procurement, assembly and stencil release are NOT authorized.
Source: current R137 PCB, KiCad10.0.7. Four copper layers,59×101×1.6mm.
All Gerber, drill, IPC and native CPL coordinates use absolute origin0,0:
X=KiCad boardX,Y=-KiCad boardY,mm; original top-side native CPL angles.
Board envelope X18..77,Y-121..-20mm. No supplier rotation/origin normalization is approved.
Gerber soldermask objects describe openings despite negative FilePolarity metadata.
Use the single native CPL and fitted review BOM together; all-classified BOM explicitly retains19 bare-PCB entries and R67 DNP.
R67 default DNP has no paste apertures. Its copper/mask and optional rework lands remain.
All assembled107 parts are on front; back paste intentionally empty.
Separate PTH/NPTH Excellon files use decimal metric coordinates and routed USB slots.
Excellon alone does NOT convey fill/cap; the five U3 UUIDs and coordinates are explicitly listed in U3_via_process_requests.csv.
All330 vias are audited:165 have0.10mm nominal annular rings (160 ordinary plus5 U3 under-EP), below PCBWay's published standard0.15mm; geometry repair or explicit approved process remains required.
Filled/capped under-EP, U1 grid/stencil, USB0.8mm stakes on1.6mm PCB, controlled90-ohm USB stackup,
thermal/fault/firmware qualification, thin replaceable battery and unchanged-thickness case fit remain open.
No current complete case CAD or qualified interchangeable CN/PL battery pair is registered.
Do not interpret Gerber availability, checksum verification or native DRC0 as factory acceptance.
