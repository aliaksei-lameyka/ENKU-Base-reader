ENKU Base R144 - CAM review only / NO FAB
PCB SHA256: 676c157fb58c1d5b689b4a6841749d8be283982745ce40580c0a33308f7e2d2c
11 Gerber layers and separate PTH/NPTH drills, in millimetres.
Six resin-fill/copper-cap sites require process acceptance; see both included CSVs.
Physical tests NOT RUN. Use the complete English review package for assembly and qualification.
